package act7java;

class NumPrimos {

    int[] SucesiónPrimos = new int[100];
    int indice = 0;
    int max;

    public int[] calcular(int max) {

        for (int i = 1; i < max; i++) {
            int almacenar = 0;
            for (int j = 1; j <= i; j++) {

                if (i % j == 0) {
                    almacenar++;
                }
            }

            if (almacenar == 2) {

                SucesiónPrimos[indice++] = i;
            }

        }
        return SucesiónPrimos;
    }
}
