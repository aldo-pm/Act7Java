package act7java;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        int almacenar;

        Scanner leer = new Scanner(System.in);
        System.out.println("Cuantos numeros se van a calcular?");
        almacenar = leer.nextInt();
        NumPrimos Sucesion = new NumPrimos();
        Fibonacci SucesionF = new Fibonacci();

        int[] SucesionPrimos = Sucesion.calcular(almacenar);
        int[] SucesionFibonacci = SucesionF.calcular(almacenar);

        System.out.println("Numeros primos:");
        for (int i = 0; i <= almacenar; i++) {
            System.out.println(SucesionPrimos[i]);
        }
        System.out.println("Sucesion de Fibonacci;");
        for (int i = 0; i <= almacenar; i++) {
            System.out.println(SucesionFibonacci[i]);
        }
    }
}
