package act7java;

class Fibonacci {

    int[] SucesionFibonacci = new int[100];

    public int[] calcular(int max) {

        int f = 0;
        int aux1 = 1;
        int aux2;

        for (int i = 0; i <= max; i++) {
            aux2 = f;
            f = aux1 + f;
            aux1 = aux2;
            SucesionFibonacci[i] = aux1;

        }
        return SucesionFibonacci;
    }
}
